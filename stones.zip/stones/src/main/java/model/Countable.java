package model;

public interface Countable {
	
	double countPrice();

}
