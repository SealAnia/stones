package model;

public class AmberNecklace extends Necklace<Amber> {
	
	public Amber amber;
	
	public AmberNecklace(Amber amber) {
		super(amber);
	}

}
