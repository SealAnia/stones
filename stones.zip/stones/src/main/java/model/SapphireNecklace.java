package model;

public class SapphireNecklace extends Necklace<Sapphire> {
	
	public Sapphire sapphire;
	
	public SapphireNecklace(Sapphire sapphire) {
		super(sapphire);
	}
	
}
