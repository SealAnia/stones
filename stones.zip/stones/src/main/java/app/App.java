package app;

import util.Jubiler;

public class App {

	public static void main(String[] args) {
		
		Jubiler j = new Jubiler();
		
		//j.amberNecklaceMaker.makeNecklace(null);
		j.diamondNecklaceMaker.makeNecklace(null);
		j.rubyNecklaceMaker.makeNecklace(null);
		j.sapphireNecklaceMaker.makeNecklace(null);
		
	}

}
