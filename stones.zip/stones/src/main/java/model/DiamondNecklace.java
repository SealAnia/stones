package model;

public class DiamondNecklace extends Necklace<Diamond> {
	
	public Diamond diamond;
	
	public DiamondNecklace(Diamond diamond) {
		super(diamond);
	}
	
}
