package model;

public class Opal extends SemipreciousStone {

}
