package model;

public class RubyNecklace extends Necklace<Ruby> {
	
	public Ruby ruby;
	
	public RubyNecklace(Ruby ruby) {
		super(ruby);
	}
	
}
