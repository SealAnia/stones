package model;

public class Malachit extends SemipreciousStone {

}
